//
// Created by maros on 23/05/2024.
//

#ifndef ALICIA_HPP
#define ALICIA_HPP

#include <array>
#include <cstdint>

#include "util.hpp"

#endif // ALICIA_HPP
